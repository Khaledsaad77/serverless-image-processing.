// Lambda image processor using Jimp (pure JS, no native deps)
// Runtime: Node.js 20.x
// Handler: index.handler

const AWS = require("aws-sdk");
const S3 = new AWS.S3();
const Jimp = require("jimp");

const OUTPUT_BUCKET = process.env.OUTPUT_BUCKET;
const MAX_WIDTH = parseInt(process.env.MAX_WIDTH || "1024", 10);
const WATERMARK_TEXT = process.env.WATERMARK_TEXT; // optional

exports.handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  try {
    const record = event.Records && event.Records[0];
    if (!record) throw new Error("No S3 record in event");

    const srcBucket = record.s3.bucket.name;
    // Handle URL-encoded keys
    const srcKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));

    // Fetch object head to get content-type (fallback if needed)
    let contentType = record.s3.object.contentType;
    if (!contentType) {
      const head = await S3.headObject({ Bucket: srcBucket, Key: srcKey }).promise();
      contentType = head.ContentType;
    }

    if (!contentType || !contentType.startsWith("image/")) {
      console.log(`Skipping non-image object: ${srcKey} (${contentType})`);
      return { statusCode: 200, body: "Not an image — skipped." };
    }

    // Get object bytes
    const obj = await S3.getObject({ Bucket: srcBucket, Key: srcKey }).promise();
    const image = await Jimp.read(obj.Body);

    // Resize keeping aspect ratio — only if larger than MAX_WIDTH
    if (image.getWidth() > MAX_WIDTH) {
      image.resize(MAX_WIDTH, Jimp.AUTO);
    }

    // Optional watermark
    if (WATERMARK_TEXT && WATERMARK_TEXT.trim().length > 0) {
      const font = await Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
      const margin = 16;
      const textWidth = Jimp.measureText(font, WATERMARK_TEXT);
      const textHeight = Jimp.measureTextHeight(font, WATERMARK_TEXT, textWidth);
      image.print(
        font,
        image.getWidth() - textWidth - margin,
        image.getHeight() - textHeight - margin,
        WATERMARK_TEXT
      );
    }

    // Determine output format based on original content-type
    let mime = Jimp.MIME_JPEG;
    if (contentType.includes("png")) mime = Jimp.MIME_PNG;
    else if (contentType.includes("jpeg") || contentType.includes("jpg")) mime = Jimp.MIME_JPEG;
    else if (contentType.includes("webp")) mime = Jimp.MIME_WEBP;

    const outBuffer = await image.getBufferAsync(mime);

    const dstBucket = OUTPUT_BUCKET || srcBucket.replace("input", "output");
    const putParams = {
      Bucket: dstBucket,
      Key: srcKey,
      Body: outBuffer,
      ContentType: mime,
    };

    await S3.putObject(putParams).promise();

    console.log(`Processed ${srcKey} -> s3://${dstBucket}/${srcKey}`);
    return {
      statusCode: 200,
      body: `Image processed -> s3://${dstBucket}/${srcKey}`,
    };
  } catch (err) {
    console.error("Processing error:", err);
    throw err;
  }
};
