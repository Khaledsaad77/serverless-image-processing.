# Serverless Image Processing on AWS

This project implements a **serverless image processing pipeline** on AWS.
When a user uploads an image to an **S3 Input bucket**, an **AWS Lambda** function
is triggered to resize (and optionally watermark) the image, then stores the result
in an **S3 Output bucket**.

## Architecture
See `architecture.png`.

### Workflow
1. User uploads an image to the **Input S3 bucket**.
2. S3 event notification triggers the **Lambda** function.
3. Lambda resizes (optionally watermarks) the image.
4. Lambda writes the processed image to the **Output S3 bucket**.
5. **CloudWatch Logs** capture execution logs; **SNS** (optional) can notify on success/failure.

## AWS Services
- Amazon S3 (Input / Output)
- AWS Lambda (Node.js 20)
- Amazon CloudWatch Logs
- Amazon SNS (optional)
- AWS IAM (execution role & permissions)

## Deploy (Console — Quick)
1. Create two buckets (names must be globally unique):
   - `input-images-bucket-YOURNAME`
   - `output-images-bucket-YOURNAME`
   > Keep **Block all public access** ON (recommended).

2. Create an IAM role for Lambda:
   - **Trust policy**: `trust-policy.json` (Lambda service principal)
   - **Permissions policy**: edit `iam-policy.json` and replace `YOUR-INPUT-BUCKET` and `YOUR-OUTPUT-BUCKET` with your bucket names, then attach it to the role.

3. Create a Lambda function:
   - Runtime: **Node.js 20.x**
   - Architecture: `x86_64` or `arm64` (either works with Jimp; default `x86_64` is fine).
   - Handler: `index.handler`
   - Upload code from `lambda/index.js` zipped with `node_modules` (see CLI section below).
   - Environment variables (recommended):
     - `OUTPUT_BUCKET` = your output bucket name
     - `MAX_WIDTH` = `1024` (or any max width)
     - `WATERMARK_TEXT` = optional string to stamp

4. Add an S3 trigger on the **Input** bucket:
   - Event type: `PUT (ObjectCreated:Put)`
   - Prefix/Suffix filters (optional, e.g., `images/`, `.jpg`)

5. Test:
   - Upload an image to the input bucket.
   - Check the output bucket for the processed version.
   - See logs in **CloudWatch Logs** for troubleshooting.

## Deploy (CLI — Optional)
```bash
# Set variables
INPUT_BUCKET=input-images-bucket-YOURNAME
OUTPUT_BUCKET=output-images-bucket-YOURNAME
ROLE_NAME=lambda-image-processor-role
FUNCTION_NAME=image-processor

# Create IAM role (trust policy)
aws iam create-role   --role-name $ROLE_NAME   --assume-role-policy-document file://trust-policy.json

# Create and attach permissions policy
aws iam put-role-policy   --role-name $ROLE_NAME   --policy-name image-processor-inline   --policy-document file://iam-policy.json

# Prepare Lambda package (Node.js + Jimp)
mkdir -p lambda && cd lambda
npm init -y
npm install jimp
# Place index.js from this repo into lambda/
zip -r ../lambda-package.zip .
cd ..

# Create Lambda function
aws lambda create-function   --function-name $FUNCTION_NAME   --runtime nodejs20.x   --role arn:aws:iam::<ACCOUNT_ID>:role/$ROLE_NAME   --handler index.handler   --environment Variables="{OUTPUT_BUCKET=$OUTPUT_BUCKET,MAX_WIDTH=1024}"   --zip-file fileb://lambda-package.zip

# Add S3 trigger (notification)
aws lambda add-permission   --function-name $FUNCTION_NAME   --statement-id s3invoke   --action lambda:InvokeFunction   --principal s3.amazonaws.com   --source-arn arn:aws:s3:::$INPUT_BUCKET   --source-account <ACCOUNT_ID>

aws s3api put-bucket-notification-configuration   --bucket $INPUT_BUCKET   --notification-configuration '{
    "LambdaFunctionConfigurations": [{
      "LambdaFunctionArn": "arn:aws:lambda:<REGION>:<ACCOUNT_ID>:function:'"$FUNCTION_NAME"'",
      "Events": ["s3:ObjectCreated:Put"]
    }]
  }'
```

## Repo Structure
```
.
├── README.md
├── architecture.png
├── iam-policy.json
├── trust-policy.json
└── lambda
    └── index.js
```

## Notes (Arabic)
- **المشروع سيرفرلس بالكامل** — مفيش EC2 ولا إعدادات شبكات معقدة.
- لو محتاج ووتـرمارك، ضيف قيمة في المتغير `WATERMARK_TEXT` وهتتطبع تلقائيًا.
- يفضل ترك البكتس **خاصة**، واستخدام الروابط الموقعة (pre-signed) لو عايز تشارك صور.

---

© 2025
